import React from "react";
import { Grid, Typography, Button, Divider } from "@material-ui/core";
import "./userDetail.css";
import Mention from "./Mention";
import axios from "axios";

const DETAILS = "Info about ";

class UserDetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            user: null,
            comment: "",
            photos: undefined,
            favorite_ids: [] // should be  array of photo ids
        };
        this.fetchUserData(props.match.params.userId);
    }

    fetchUserData = (userId) => {
        axios
            .get(`/user/${userId}`)
            .then((response) => {
                const newUser = response.data;
                this.setState({
                    user: newUser,
                    comment: "", // To initialize comment to an empty string
                    photos: undefined, // To initialize photos to undefined
                    favorite_ids: [] // To initialize favorite_ids to an empty array
                });
                this.props.changeView(
                    DETAILS,
                    `${newUser.first_name} ${newUser.last_name}`
                );
            })
            .catch((err) => console.log(err.response));
    };

    handleSeePhotosClick = () => {
        const { user } = this.state;
        if (user) {
            // Navigate to UserPhotos and pass user data
            this.props.history.push({
                pathname: `/photos/${user._id}`,
                state: { user: this.state.user }
            });
        } else {
            console.error("User details not found");
        }
    };

    componentDidUpdate = (prevProps, prevState) => {
        const newUserID = this.props.match.params.userId;
        if (this.state.user && this.state.user._id !== newUserID) {
            this.fetchUserData(newUserID);
        }

        // Print updated state and props
        console.log("Updated State:", this.state);
        console.log("Updated Props:", this.props);
    };

    render() {
        return this.state.user ? (
            <Grid
                container
                justify="space-evenly"
                alignItems="center"
                style={{ backgroundColor: "#e5dacd" }} // Set background color
            >
                <Grid xs={6} item>
                    <Typography variant="h3">
                        {`${this.state.user.first_name} ${this.state.user.last_name}`}
                    </Typography>
                    <Typography variant="h5">
                        {this.state.user.occupation} <br />
                        based in {this.state.user.location}
                    </Typography>
                    <Typography variant="body1">{this.state.user.description}</Typography>
                    <br />
                    <Divider />
                    <br />
                    <Typography variant="h5">Mentioned in:</Typography>
                    <br />

                    {this.state.user.mentioned.length > 0 ? (
                        this.state.user.mentioned.map((photo_id, i) => {
                            return <Mention key={photo_id + i} photo_id={photo_id} />;
                        })
                    ) : (
                        <Typography variant="h5">None</Typography>
                    )}
                </Grid>
                <Grid xs={4} item>
                    <Button
                        variant="contained"
                        size="large"
                        onClick={this.handleSeePhotosClick}
                        style={{ backgroundColor: "#ccb4a4", marginTop: 20 }} // Set button color and style
                    >
                        See photos
                    </Button>
                </Grid>
            </Grid>
        ) : (
            <div />
        );
    }
}

export default UserDetail;
