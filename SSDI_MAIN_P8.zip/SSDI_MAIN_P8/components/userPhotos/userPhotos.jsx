import React from "react";
import { Typography, Grid } from "@material-ui/core";
import "./userPhotos.css";
import PhotoCard from "./PhotoCard";
const axios = require("axios").default;

class UserPhotos extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            photos: [],
            comment: "",
            favorite_ids: [],
            loading: true,
        };

        

        if (props.location && props.location.state && props.location.state.user) {
            this.user = props.location.state.user;
            this.userId = this.user._id;
            this.refreshCards();
        } else {
            console.error("User details not found in props.location.state");
        }
    }

    refreshCards() {
        if (this.userId) {
            console.log("Fetching user photos...");
            this.setState({ loading: true });

            axios
                .get(`/photosOfUser/${this.userId}`)
                .then((response) => {
                    console.log("Received Photos:", response.data);

                    // Log entire response data for further inspection
                    console.log("Response Data:", response.data);

                   
                    const photoIds = response.data.map((photo) => photo._id);
                    console.log("Photo IDs:", photoIds);

                    this.setState({ photos: response.data, loading: false });
                })
                .catch((err) => {
                    console.error("Error fetching user photos:", err.response || err.message);
                    // Handle error and update state accordingly
                    this.setState({ loading: false });
                });

            axios
                .get(`/getFavorites`)
                .then((response) => {
                    console.log("Received Favorites:", response.data);

                    let favorite_ids = response.data.map((photo) => photo._id);
                    this.setState({ favorite_ids });
                })
                .catch((err) => {
                    console.error("Error fetching favorites:", err.response || err.message);
                    // Handle error and update state accordingly
                    this.setState({ loading: false });
                });
        } else {
            console.error("User ID is undefined");
           
        }
    }



    render() {
        return this.user ? (
            <div className="user-photos-container">
                <Typography variant="h3" className="user-photos-heading">
                    {this.user.first_name} {this.user.last_name}&apos;s Photos
                </Typography>
                <br />
                <br />
                {this.state.loading ? (
                    <div className="loading-indicator">Loading...</div>
                ) : (
                    <Grid
                        container
                        spacing={3}
                        justify="center"
                        alignItems="center"
                        className="photo-grid"
                    >
                        {this.state.photos && this.state.photos.length > 0 ? (
                            this.state.photos.map((photo) => (
                                <Grid item xs={12} sm={6} md={4} key={photo._id}>
                                    <PhotoCard
                                        favorited={this.state.favorite_ids.includes(photo._id)}
                                        creator={this.user}
                                        refreshCards={this.refreshCards}
                                        liked={photo.liked_by.includes(this.props.curr_user_id)}
                                        photo={photo}
                                    />
                                </Grid>
                            ))
                        ) : (
                            <div className="no-photos-message">No photos available</div>
                        )}
                    </Grid>
                )}
            </div>
        ) : (
            <div />
        );
    }

}

export default UserPhotos;
