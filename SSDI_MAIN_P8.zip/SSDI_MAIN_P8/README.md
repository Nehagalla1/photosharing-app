# SSDI_MAIN_P8

<h1>Scrum Team</h1>
<h2> Product Owner</h2>
Phani Kiran Reddy D
<h2>Scrum Master</h2>
Neha Galla
<h2>Developers</h2>
-  Moulya Madamanchi
-  Saketh Reddy Vallamreddy
-  Sai Sushma Gurram
-  Phiny Francis Govathoti
